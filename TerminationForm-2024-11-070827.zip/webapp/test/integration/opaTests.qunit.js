/* global QUnit */

sap.ui.require(["terminationformapplication/terminationformapplication/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
