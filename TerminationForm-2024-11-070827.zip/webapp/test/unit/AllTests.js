sap.ui.define([
	"termination_form_application/terminationformapplication/test/unit/controller/TerminationForm.controller"
], function () {
	"use strict";
});
